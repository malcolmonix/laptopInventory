google.charts.load('current', {'packages':['corechart']}); 
       
    // Set a callback to run when the Google Visualization API is loaded. 
    google.charts.setOnLoadCallback(drawChart); 
    var path = 'http://127.0.0.1/NCI/index.php';
    function drawChart() { 
      var jsonData = $.ajax({ 
          url: path+"/Dashboard/getStateofResidence", 
          dataType: "json", 
          async: false 
          }).responseText; 
           
      // Create our data table out of JSON data loaded from server. 
      var data = new google.visualization.DataTable(jsonData); 
 
 	var options = {
        chart: {
          title: 'Members Residence in a State',
          subtitle: 'Show members Residence'
        },
        width: 500,
        height: 300,
        axes: {
          x: {
            0: {side: 'down'}
          }
        }
	}
      // Instantiate and draw our chart, passing in some options. 
      var chart = new google.visualization.PieChart(document.getElementById('chart_div_stateofresidence')); 
      chart.draw(data, options); 
    } 